//
//  ViewController.swift
//  CustomMapAnnotation
//
//  Created by Luke Van In on 2016/07/14.
//  Copyright © 2016 Luke Van In. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {

    var locationManager: CLLocationManager?
    var arrReef : NSMutableArray = []
    
    var currentLocation: MKUserLocation? {
        didSet {
            button.isHidden = (currentLocation == nil)
        }
    }

    lazy var formatter: DateFormatter = {

        let formatter = DateFormatter()
//        formatter.timeStyle = DateFormatter.Style.ShortStyle
        formatter.timeStyle = .short
        formatter.dateStyle = .short
        return formatter
    }()

    @IBOutlet var button: UIButton!
    @IBOutlet var mapView: MKMapView!

    override func viewDidLoad() {

        super.viewDidLoad()

        if CLLocationManager.locationServicesEnabled() {

            locationManager = CLLocationManager()
            locationManager?.delegate = self
            locationManager?.desiredAccuracy = kCLLocationAccuracyBest

            switch CLLocationManager.authorizationStatus() {

            case .authorizedAlways, .authorizedWhenInUse:
                locationManager?.startUpdatingLocation()
                mapView.showsUserLocation = true

            default:
                locationManager?.requestWhenInUseAuthorization()
            }
        }
        
        
        
        arrReef = [["title":"Ahmedabad","latitude": "23.0225","longitude":"72.5714"],
                ["title":"Surat","latitude": "21.1702","longitude":"72.8311"],
                ["title":"Junagadh","latitude": "21.5222","longitude":"70.4579"],
                ["title":"Bhuj","latitude": "23.2420","longitude":"69.6669"],
                ["title":"Vadodara","latitude": "22.3072","longitude":"73.1812"]]

        
        let reportTime = NSDate()
        let formattedTime = formatter.string(from: reportTime as Date)
        
//        annotation.subtitle = formattedTime

        
        for i in 0..<arrReef.count
        {
            let dict = arrReef[i] as! NSDictionary
            
            let annotation = MKPointAnnotation()
            annotation.title = dict["title"] as? String

            let latitude:CLLocationDegrees = Double(dict["latitude"] as! String)!
            
            let longitude:CLLocationDegrees = Double(dict["longitude"] as! String)!
            
            let homeLocation = CLLocation(latitude: latitude  , longitude: longitude )
            
            annotation.coordinate = CLLocationCoordinate2D(latitude: homeLocation.coordinate.latitude, longitude: homeLocation.coordinate.longitude)
            mapView.addAnnotation(annotation)

        }
        

    }

    private func locationManager(manager: CLLocationManager, didChangeAuthorizationStatus status: CLAuthorizationStatus) {

        switch status {

        case .authorizedAlways, .authorizedWhenInUse:
            locationManager?.startUpdatingLocation()
            mapView.showsUserLocation = true

        case .denied, .restricted:
            locationManager?.startUpdatingLocation()
            mapView.showsUserLocation = false
            currentLocation = nil

        default:
            currentLocation = nil
        }
    }

    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {

        currentLocation = userLocation
    }

    @IBAction func addButtonTapped(sender: AnyObject) {

        guard let coordinate = currentLocation?.coordinate else {
            return
        }

        let reportTime = NSDate()
        let formattedTime = formatter.string(from: reportTime as Date)

        let annotation = MKPointAnnotation()
        annotation.title = "Annotation Created"
        annotation.subtitle = formattedTime
//        annotation.coordinate = coordinate
        
        
    }

    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {

        guard !annotation.isKind(of: MKUserLocation.self) else {

            return nil
        }

        let annotationIdentifier = "AnnotationIdentifier"

        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: annotationIdentifier)
        
        if annotationView == nil {
            annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: annotationIdentifier)
            annotationView!.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
            annotationView!.canShowCallout = true
        }
        else {
            annotationView!.annotation = annotation
        }

        annotationView!.image = UIImage(named: "smile")

        return annotationView

    }
}

